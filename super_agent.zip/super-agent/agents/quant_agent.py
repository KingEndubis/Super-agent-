class QuantAgent:
    pass
