class PrivacyAgent:
    pass
